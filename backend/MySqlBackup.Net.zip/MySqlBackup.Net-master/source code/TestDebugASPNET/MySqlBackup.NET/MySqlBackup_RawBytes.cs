﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MySqlConnector
{
    public class MySqlBackup_RawBytes
    {
    }
}