﻿/*

The content of this file has moved to the CSS folder at


/cssjs/MySqlBackup-Progress-Widget-Theme/light.css
/cssjs/MySqlBackup-Progress-Widget-Theme/dark.css
/cssjs/MySqlBackup-Progress-Widget-Theme/cyberpunk.css
/cssjs/MySqlBackup-Progress-Widget-Theme/retro.css
/cssjs/MySqlBackup-Progress-Widget-Theme/steampunk.css
/cssjs/MySqlBackup-Progress-Widget-Theme/solarfire.css
/cssjs/MySqlBackup-Progress-Widget-Theme/hud.css


*/